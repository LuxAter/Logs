"""Pessum based log viewer"""
